"""Indicadores con denominadores explícitos y faltantes conservados."""
import calendar
import numpy as np
import pandas as pd
def ventana(periodo,corte):
 p=pd.Period(periodo,freq='M');return p.start_time.normalize(),min(p.end_time.normalize(),pd.Timestamp(corte).normalize())
def anterior(periodo):return str(pd.Period(periodo,freq='M')-1)
def filtrar(df,inicio,fin,col='fecha'):return df[df[col].between(pd.Timestamp(inicio),pd.Timestamp(fin))].copy()
def ventanas_comparables(periodo,corte):
 inicio,fin=ventana(periodo,corte);prev=pd.Period(periodo,freq='M')-1
 finprev=pd.Timestamp(prev.year,prev.month,min(fin.day,calendar.monthrange(prev.year,prev.month)[1]))
 return inicio,fin,prev.start_time.normalize(),finprev
def resumen_dias(df):
 d=df.copy();factor=pd.Series(1.0,index=d.index)
 presente=d['registro_presente'].fillna(False).astype(bool);taller=presente & d['en_taller'].eq(1);disponible=presente & d['en_taller'].eq(0)
 viaje=disponible & d['con_viaje'].eq(1);sinviaje=disponible & d['con_viaje'].eq(0)
 def suma(mask):return float(factor[mask].sum())
 total=float(factor.sum());disp=suma(disponible);trab=suma(viaje)
 return {'base':total,'disponibles':disp,'viaje':trab,'taller':suma(taller),'sin_viaje':suma(sinviaje),'sin_registro':suma(~presente),
 'solapados':suma(taller & d['con_viaje'].eq(1)),'viaje_estimado':suma(presente & d['viaje_estimado'].eq(1)),
 'disponibilidad_pct':100*disp/total if total else None,'uso_registrado_pct':100*trab/disp if disp else None}
def ponderado(df,km='km',rendimiento='rendimiento'):
 d=df[df[rendimiento].between(1,4,inclusive='both') & df[km].gt(0)]
 return float((d[km]*d[rendimiento]).sum()/d[km].sum()) if not d.empty else None
def combustible(df):
 return {'litros':df['litros'].sum(min_count=1),'km':df['km'].sum(min_count=1),'km_gps':df['km_gps'].sum(min_count=1),
 'rendimiento':ponderado(df),'rendimiento_gps':ponderado(df,'km_gps','rendimiento_gps'),'validos':int(df['rendimiento'].between(1,4).sum()),'con_litros':int(df['litros'].gt(0).sum())}
def actividad_personas(df,catalogo):
 if df.empty:return pd.DataFrame()
 d=df.groupby('conductor_id',as_index=False).agg(ingreso=('ingreso',lambda x:x.sum(min_count=1)),viajes=('viajes','sum'),km=('km',lambda x:x.sum(min_count=1)),litros=('litros',lambda x:x.sum(min_count=1)))
 d=d.merge(catalogo,on='conductor_id',how='left',validate='one_to_one');d['grupo']=d['grupo'].fillna('Sin grupo comparable')
 medias=d.groupby('grupo')['ingreso'].transform('mean');n=d.groupby('grupo')['ingreso'].transform('count')
 d['ingreso_relativo']=np.where((n>=2)&medias.gt(0),100*d['ingreso']/medias,np.nan)
 return d

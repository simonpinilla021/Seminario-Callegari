"""Datos sintéticos reproducibles. No lee archivos privados ni abre conexiones."""
import os
import pandas as pd
import streamlit as st


def solo_demo():
    return os.getenv('CALLEGARI_SOLO_DEMO', '').lower() in {'1', 'true', 'si'}


def activa():
    return solo_demo() or bool(st.session_state.get('modo_demo', False))


@st.cache_data(show_spinner=False)
def tablas():
    inicio, corte = pd.Timestamp('2025-01-01'), pd.Timestamp('2026-10-31')
    equipos = pd.DataFrame([dict(equipo_id=i, patente=f'DEMO-{i:02}', codigo=f'C{i:02}',
        camion=f'DEMO-{i:02} C{i:02}', marca=['Marca A','Marca B'][i % 2],
        modelo=f'Modelo {i % 3 + 1}', anio_fabricacion=2020+i%5, estado_actual='O') for i in range(1, 9)])
    conductores = pd.DataFrame([dict(conductor_id=f'DEMO-{i:03}', conductor=f'Conductor ficticio {i:02}',
        grupo='Demostración', origen='Ficticio · no representa una persona real') for i in range(1, 13)])
    ventas, actividad, diario, km, retornos, combustible = [], [], [], [], [], []
    for fecha in pd.date_range(inicio, corte):
        for j in range(4):
            viajes = 2 + (fecha.day+j+fecha.month) % 5
            ingreso = viajes * (280000 + j*65000 + fecha.month*8000)
            ventas.append(dict(fecha=fecha, cliente=f'Cliente ficticio {j+1}', operador=['propio','fletero','caterina','propio'][j], viajes=viajes, ingreso=ingreso, viajes_con_ingreso=viajes))
            actividad.append(dict(fecha=fecha, conductor_id=f'DEMO-{(fecha.day+j)%12+1:03}', viajes=viajes, ingreso=ingreso, km=float('nan'), litros=float('nan')))
            corredor=['Zona Norte → Centro','Centro → Zona Sur','Zona Sur → Centro','Centro → Zona Norte'][j]
            km.append(dict(fecha=fecha, corredor=corredor, movimientos_alcance=viajes+1, movimientos_evaluables=viajes, km_reales_evaluables=viajes*(180+j*120), km_vacios_reales=(180+j*120)*(1+(fecha.day%3==0))))
            retornos.append(dict(fecha=fecha, corredor=corredor, cliente=f'Cliente ficticio {j+1}', tipo_operador=['propio','fletero','caterina','propio'][j]))
        for e in equipos.to_dict('records'):
            n=(fecha.day+e['equipo_id']*3)%20
            presente=n!=0; taller=n in {1,2}; viaje=n>5
            estado='Sin registro' if not presente else 'Taller' if taller else 'Viaje registrado' if viaje else 'Disponible sin viaje registrado'
            diario.append(dict(**{k:e[k] for k in ['equipo_id','camion','marca','modelo']}, fecha=fecha,
                registro_presente=presente, en_taller=int(taller), con_viaje=int(viaje), horas_taller=8*int(taller), viaje_estimado=0, estado=estado, dias_mes=fecha.days_in_month))
    for mes in pd.date_range(inicio, corte, freq='MS'):
        for e in equipos.to_dict('records'):
            litros=2200+e['equipo_id']*85+mes.month*35; rendimiento=2.1+e['equipo_id']*.055+(mes.month%4)*.03
            combustible.append(dict(**{k:e[k] for k in ['equipo_id','camion','patente','codigo','marca','modelo']}, mes=mes,
                litros=litros, km=litros*rendimiento, km_gps=litros*rendimiento*.98, rendimiento=rendimiento, rendimiento_gps=rendimiento*.98, calidad='Extremos disponibles'))
    ramplas=pd.DataFrame([dict(equipo_id=100+i, patente=f'REMO-{i:02}', codigo=f'R{i:02}', rampla=f'REMO-{i:02} R{i:02}', categoria=['Plana','Furgón'][i%2], marca='Marca ficticia', modelo='Modelo demo', estado_actual='O') for i in range(1,9)])
    relaciones=pd.DataFrame([dict(equipo_id=i,rampla_id=100+i,registros=50+i*5,primera_fecha=inicio,ultima_fecha=corte) for i in range(1,9)])
    return dict(configuracion=pd.DataFrame([dict(fecha_inicio=inicio,fecha_corte=corte,fuente='Datos sintéticos de demostración',version_contrato=1)]),
        equipos=equipos, conductores=conductores, ventas_diarias=pd.DataFrame(ventas), actividad_conductores=pd.DataFrame(actividad),
        estado_diario=pd.DataFrame(diario), km_corredor=pd.DataFrame(km), retornos=pd.DataFrame(retornos),
        combustible_mes=pd.DataFrame(combustible), ramplas=ramplas, relaciones_equipo=relaciones)


def leer(tabla):
    return tablas()[tabla].copy(deep=True)

"""Solo complementos simulados. Nunca escribe en PostgreSQL."""
from pathlib import Path
from datetime import date
import os,sqlite3,hashlib
from contextlib import contextmanager
import pandas as pd
import streamlit as st
from core import demo
ROOT=Path(__file__).resolve().parents[1]
CONDUCTORES=pd.DataFrame([{'conductor_id':f'DEMO-{i:03}','conductor':f'Conductor ilustrativo {i:02}','grupo':'Ilustrativo','origen':'Ilustrativo · no es una persona real'} for i in range(1,13)])
def ruta_db():return Path(os.getenv('CALLEGARI_COMPLEMENTOS_DB',str(ROOT/'datos_locales/complementos.sqlite3')))
@contextmanager
def conexion():
 if demo.activa():
  if '_demo_sqlite' not in st.session_state:
   st.session_state['_demo_sqlite']=sqlite3.connect(':memory:',check_same_thread=False)
  c=st.session_state['_demo_sqlite'];c.row_factory=sqlite3.Row
 else:
  c=None
 if c is None:
  p=ruta_db();p.parent.mkdir(parents=True,exist_ok=True);c=sqlite3.connect(p,timeout=10);c.row_factory=sqlite3.Row
 c.execute('''CREATE TABLE IF NOT EXISTS bloqueos (id INTEGER PRIMARY KEY,entorno TEXT NOT NULL,conductor_id TEXT NOT NULL,cliente TEXT NOT NULL,motivo TEXT NOT NULL,desde TEXT NOT NULL,hasta TEXT,activo INTEGER NOT NULL,actualizado_por TEXT,actualizado_en TEXT DEFAULT CURRENT_TIMESTAMP)''')
 c.execute('''CREATE TABLE IF NOT EXISTS eventos (id INTEGER PRIMARY KEY,bloqueo_id INTEGER,entorno TEXT,accion TEXT,usuario TEXT,fecha TEXT DEFAULT CURRENT_TIMESTAMP)''')
 try:
  with c:yield c
 finally:
  if not demo.activa():c.close()
def guardar(entorno,conductor_id,cliente,motivo,desde,hasta,activo,usuario,id=None):
 if hasta and hasta<desde:raise ValueError('La fecha de término debe ser igual o posterior al inicio.')
 if not str(conductor_id).strip() or not str(cliente).strip():raise ValueError('Seleccione conductor y cliente.')
 if not str(motivo).strip():raise ValueError('Escriba un motivo ilustrativo.')
 if len(motivo)>500:raise ValueError('El motivo admite hasta 500 caracteres.')
 with conexion() as c:
  vals=(conductor_id,cliente,motivo.strip(),desde.isoformat(),hasta.isoformat() if hasta else None,int(activo),usuario)
  if id is None:
   id=c.execute('INSERT INTO bloqueos (conductor_id,cliente,motivo,desde,hasta,activo,actualizado_por,entorno) VALUES (?,?,?,?,?,?,?,?)',(*vals,entorno)).lastrowid;accion='crear'
  else:
   cur=c.execute('UPDATE bloqueos SET conductor_id=?,cliente=?,motivo=?,desde=?,hasta=?,activo=?,actualizado_por=?,actualizado_en=CURRENT_TIMESTAMP WHERE id=? AND entorno=?',(*vals,id,entorno))
   if cur.rowcount!=1:raise ValueError('El registro ya no está disponible en esta conexión.')
   accion='editar'
  c.execute('INSERT INTO eventos(bloqueo_id,entorno,accion,usuario) VALUES (?,?,?,?)',(id,entorno,accion,usuario))
 return id
def leer(entorno):
 with conexion() as c:df=pd.read_sql_query('SELECT * FROM bloqueos WHERE entorno=? ORDER BY id',c,params=(entorno,))
 if not df.empty:df['activo']=df['activo'].astype(bool)
 return df
def desactivar(entorno,id,usuario):
 with conexion() as c:
  cur=c.execute('UPDATE bloqueos SET activo=0,actualizado_por=?,actualizado_en=CURRENT_TIMESTAMP WHERE id=? AND entorno=? AND activo=1',(usuario,id,entorno))
  if cur.rowcount!=1:raise ValueError('El bloqueo ya está inactivo o no pertenece a esta conexión.')
  c.execute('INSERT INTO eventos(bloqueo_id,entorno,accion,usuario) VALUES (?,?,?,?)',(id,entorno,'desactivar',usuario))

def sembrar(entorno,conductores,clientes):
 if conductores.empty or not conductores['conductor_id'].astype(str).str.startswith('DEMO-').all() or not clientes:return
 with conexion() as c:
  if c.execute('SELECT count(*) FROM bloqueos WHERE entorno=?',(entorno,)).fetchone()[0]:return
  for i in range(min(3,len(conductores),len(clientes))):
   c.execute('INSERT INTO bloqueos(entorno,conductor_id,cliente,motivo,desde,activo,actualizado_por) VALUES (?,?,?,?,?,?,?)',(entorno,conductores.iloc[i]['conductor_id'],clientes[i],'Ejemplo de restricción por cliente; motivo simulado.',date(2026,1,1).isoformat(),1,'Semilla ilustrativa'))
def vigentes(df,fecha):
 if df.empty:return df.copy()
 fecha=pd.Timestamp(fecha)
 return df[df['activo'] & pd.to_datetime(df['desde']).le(fecha) & (df['hasta'].isna()|pd.to_datetime(df['hasta']).ge(fecha))].copy()
def dimensiones(ramplas):
 d=ramplas.copy()
 variantes=[(13.6,2.45,2.6),(13.4,2.4,2.55),(14.0,2.46,2.65),(12.5,2.4,2.5)]
 def indice(x):return int(hashlib.sha256(str(x).encode()).hexdigest()[:8],16)
 v=[variantes[indice(x)%len(variantes)] for x in d['equipo_id']]
 for i,k in enumerate(['largo_interior_m','ancho_interior_m','alto_interior_m']):d[k]=[x[i] for x in v]
 d['origen_dimensiones']='Ilustrativo · pendiente de medición'
 return d

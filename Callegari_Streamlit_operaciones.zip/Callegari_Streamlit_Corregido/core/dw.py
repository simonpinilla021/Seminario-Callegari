"""Consultas exclusivamente de lectura al contrato PostgreSQL de Operaciones."""
from pathlib import Path
import os,re,tomllib,logging,json
from datetime import datetime
from core import demo
import pandas as pd
import streamlit as st
RAIZ=Path(__file__).resolve().parents[1]
import psycopg
from psycopg import sql
TABLAS={'configuracion','equipos','ventas_diarias','combustible_mes','estado_diario','ramplas','relaciones_equipo','conductores','actividad_conductores','retornos','km_corredor'}
class ErrorDW(RuntimeError):pass

def explicar_error(error):
 """Clasificar sin mostrar la cadena original, que podría contener credenciales."""
 code=getattr(error,'sqlstate',None)
 detail=str(error).lower()
 if code in {'28P01','28000'} or 'password authentication failed' in detail or 'no password supplied' in detail:
  return 'DW-AUTH: PostgreSQL rechazó la autenticación o no recibió contraseña. Revise las credenciales del perfil y el archivo pgpass.'
 if code=='3D000':return 'DW-BASE: la base de datos configurada no existe en ese servidor.'
 if code in {'42P01','3F000'}:return 'DW-CONTRATO: falta el esquema o una vista de operaciones_app. Revise Datos y conexión e instale el contrato SQL.'
 if code=='42501':return 'DW-PERMISOS: el usuario de PostgreSQL no tiene permiso de lectura sobre las vistas o sus fuentes.'
 if code=='57014':return 'DW-TIEMPO: la consulta superó el tiempo permitido. Revise la carga y el rendimiento del DW.'
 if '10013' in detail or '0000271d' in detail or 'permission denied' in detail:
  return 'DW-RED-BLOQUEADA: Windows o el entorno que inició Streamlit bloquea la conexión a PostgreSQL. Inicie el tablero desde Iniciar_Operaciones.cmd fuera del entorno restringido.'
 if 'connection refused' in detail or 'actively refused' in detail or '10061' in detail:
  return 'DW-SERVIDOR: PostgreSQL no está escuchando en el servidor y puerto configurados. Compruebe el servicio y la conexión seleccionada.'
 if 'timeout' in detail or 'timed out' in detail:
  return 'DW-RED-TIEMPO: no se pudo conectar dentro del plazo. Compruebe servidor, puerto y conectividad.'
 return 'DW-CONSULTA: falló la consulta al DW. Compruebe el perfil y las vistas en Datos y conexión.'

def perfiles():
 if demo.activa():return {"perfil_predeterminado":"demo","perfiles":{"demo":{"etiqueta":"Demostración · sin DW"}}}
 ruta=Path(os.getenv('CALLEGARI_CONFIG',str(RAIZ/'conexion.toml')))
 with ruta.open('rb') as f:return tomllib.load(f)

def configuracion_perfil(perfil):
 if demo.activa():return dict(host='Sin conexión',port=0,dbname='Datos ficticios',schema='demo',sslmode='disable')
 d=perfiles()['perfiles'][perfil].copy()
 if not re.fullmatch(r'[a-zA-Z_][a-zA-Z0-9_]*',d.get('schema','')):raise ErrorDW('El esquema configurado no es válido.')
 if d.get('sslmode') not in {'disable','allow','prefer','require','verify-ca','verify-full'}:raise ErrorDW('El modo SSL configurado no es válido.')
 return d

def _password(perfil):
 value=os.getenv('CALLEGARI_DW_PASSWORD_'+perfil.upper()) or os.getenv('CALLEGARI_DW_PASSWORD')
 if value:return value
 try:return st.secrets.get('dw',{}).get(perfil,{}).get('password')
 except (FileNotFoundError,st.errors.StreamlitSecretNotFoundError):return None

def _ruta_pgpass(config=None):
 if config and config.get('passfile'):return Path(config['passfile']).expanduser()
 if os.getenv('PGPASSFILE'):return Path(os.environ['PGPASSFILE']).expanduser()
 if os.name=='nt':return Path(os.environ.get('APPDATA',str(Path.home()/'AppData/Roaming')))/'postgresql/pgpass.conf'
 return Path.home()/'.pgpass'

def _campos_pgpass(linea):
 campos=[];actual=[];escape=False
 for c in linea.rstrip('\r\n'):
  if escape:actual.append(c);escape=False
  elif c=='\\':escape=True
  elif c==':' and len(campos)<4:campos.append(''.join(actual));actual=[]
  else:actual.append(c)
 if escape:actual.append('\\')
 return campos+[''.join(actual)]

def _password_pgpass(config):
 """Resolver en el mismo proceso de la app; no depende de la búsqueda implícita de libpq."""
 ruta=_ruta_pgpass(config)
 if not ruta.is_file():return None
 if os.name!='nt' and ruta.stat().st_mode & 0o077:return None
 esperado=[str(config[k]) for k in ['host','port','dbname','user']]
 with ruta.open(encoding='utf-8-sig') as f:
  for linea in f:
   if not linea.strip() or linea.startswith('#'):continue
   campos=_campos_pgpass(linea)
   if len(campos)==5 and all(a=='*' or a==b for a,b in zip(campos[:4],esperado)):
    return campos[4]
 return None

def _conexion(perfil):
 if demo.activa():raise ErrorDW('El modo demostración no permite conexiones al DW.')
 d=configuracion_perfil(perfil);args={k:d[k] for k in ['host','port','dbname','user','sslmode']}
 # Contraseña por perfil > PGPASSWORD explícita > primera coincidencia pgpass.
 # Pasar el valor al driver evita diferencias de resolución del archivo entre
 # el servidor Streamlit y sus procesos de ejecución en Windows.
 explicita=_password(perfil)
 pgpass=None if explicita or os.getenv('PGPASSWORD') else _password_pgpass(d)
 password=explicita or os.getenv('PGPASSWORD') or pgpass
 if password:args['password']=password
 try:
  return psycopg.connect(**args,connect_timeout=6,application_name='Callegari Operaciones',options='-c default_transaction_read_only=on -c statement_timeout=20000')
 except psycopg.Error as e:
  registro={'fecha':datetime.now().isoformat(),'pid':os.getpid(),'perfil':perfil,'host':d['host'],'puerto':d['port'],'base':d['dbname'],'usuario':d['user'],
   'origen_credencial':'perfil' if explicita else 'PGPASSWORD' if os.getenv('PGPASSWORD') else 'pgpass' if pgpass else 'sin_credencial',
   'pgpass_existe':_ruta_pgpass(d).is_file(),'pgpass_coincidente':bool(pgpass),'password_enviada':bool(password),
   'sqlstate':getattr(e,'sqlstate',None),'sin_password_en_driver':'no password supplied' in str(e).lower(),'driver':psycopg.__version__,'archivo_app':str(RAIZ)}
  registro.update(ruta_pgpass=str(_ruta_pgpass(d)),passfile_configurado=bool(d.get('passfile')),python=sys.executable)
  try:
   p=RAIZ/'datos_locales/dw_diagnostico.jsonl';p.parent.mkdir(exist_ok=True)
   with p.open('a',encoding='utf8') as f:f.write(json.dumps(registro,ensure_ascii=False)+'\n')
  except OSError:pass
  raise

@st.cache_data(ttl=300,show_spinner=False)
def _leer(perfil,tabla,firma):
 if tabla not in TABLAS:raise ErrorDW('Tabla fuera del contrato de lectura.')
 try:
  with _conexion(perfil) as con:
   esquema=configuracion_perfil(perfil)['schema']
   cur=con.execute(sql.SQL('SELECT * FROM {}.{}').format(sql.Identifier(esquema),sql.Identifier(tabla)))
   df=pd.DataFrame(cur.fetchall(),columns=[x.name for x in cur.description])
  for k in ['fecha','mes','fecha_corte','fecha_inicio','primera_fecha','ultima_fecha']:
   if k in df:df[k]=pd.to_datetime(df[k])
  return df
 except (psycopg.Error,OSError) as e:
  mensaje=explicar_error(e)
  logging.getLogger(__name__).warning('Consulta DW fallida: tabla=%s; categoría=%s',tabla,mensaje.split(':')[0])
  raise ErrorDW(mensaje) from None

def leer(tabla,perfil=None):
 if demo.activa():
  if tabla not in TABLAS:raise ErrorDW('Tabla fuera del contrato de lectura.')
  return demo.leer(tabla)
 perfil=perfil or st.session_state.get('perfil_dw',perfiles().get('perfil_predeterminado','local'))
 d=configuracion_perfil(perfil);firma=tuple(sorted((k,str(v)) for k,v in d.items()))
 return _leer(perfil,tabla,firma).copy()

def metadatos():
 df=leer('configuracion')
 if len(df)!=1 or int(df.iloc[0]['version_contrato'])!=1:raise ErrorDW('El DW no cumple la versión 1 del contrato de Operaciones.')
 return df.iloc[0]

def actualizar():st.cache_data.clear()

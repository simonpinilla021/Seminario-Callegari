## Para tener una demostración sin datos reales

Para revisar el diseño sin PostgreSQL ni credenciales:

```powershell
python -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app_demo.py
```


También se puede usar `Iniciar_Demostracion.cmd` una vez instalado y configurado.

Esta entrada abre directamente una versión exclusivamente ficticia. No necesita
`conexion.toml`, `.streamlit/secrets.toml` ni instalar el SQL del DW.
Incluye las nueve páginas, filtros, gráficos y descargas CSV de ejemplo.
Los bloqueos editados se guardan en memoria solo durante la sesión del visitante.
Los datos sintéticos son reproducibles y cubren enero 2025 a octubre 2026.

------------------------------------------------------------

# Instalación Callegari · Jefe de Operaciones

Aplicación Streamlit con nueve páginas: resumen, ventas por cliente, actividad de conductores, recorridos y retornos, combustible, disponibilidad, conductores y bloqueos, ramplas y conexión.

## Requisitos

- Python 3.11 o superior.
- PostgreSQL accesible con el esquema `operaciones_app` y sus vistas. El repositorio contiene la aplicación, no una copia del DW ni de los datos de la empresa.

## Instalación en Windows

Ejecutar desde esta carpeta:

```powershell
python -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.venv\Scripts\activate
pip install -r requirements.txt
copy .streamlit\secrets_ejemplo.toml .streamlit\secrets.toml
python generar_clave.py
```

Editar `conexion.toml` con los datos de PostgreSQL. En `.streamlit/secrets.toml`, pegar el hash generado en `clave_hash` y configurar el usuario de acceso. La contraseña de PostgreSQL puede configurarse en `[dw.local]` o `[dw.empresa]`, según el perfil, con la clave `password`; también se admite `CALLEGARI_DW_PASSWORD`, `CALLEGARI_DW_PASSWORD_LOCAL`, `CALLEGARI_DW_PASSWORD_EMPRESA` o pgpass.

```powershell
streamlit run app.py
```

También se puede usar `Iniciar_Operaciones.cmd` una vez instalado y configurado.

## Contrato de datos

`sql/operaciones_app.sql` define las vistas de lectura que espera la aplicación sobre un DW existente. Revisar sus fuentes con el administrador de PostgreSQL antes de instalarlo; no crea ni carga el DW completo. Usar un usuario con permisos de lectura.

Los indicadores y conductores proceden del DW. Las dimensiones de ramplas y los bloqueos por cliente son complementos ilustrativos; sus cambios se almacenan en `datos_locales/`, que se genera durante el uso.




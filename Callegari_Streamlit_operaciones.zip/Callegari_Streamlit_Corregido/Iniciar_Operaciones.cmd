@echo off
cd /d "%~dp0"
if not exist conexion.toml copy conexion.ejemplo.toml conexion.toml >nul
if not exist .venv\Scripts\python.exe (
  echo Primero cree el entorno e instale requirements.txt. Consulte README.md.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m streamlit run app.py

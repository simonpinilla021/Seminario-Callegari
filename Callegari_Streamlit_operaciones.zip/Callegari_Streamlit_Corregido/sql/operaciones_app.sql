--
-- PostgreSQL database dump
--

\restrict 7WaQqFOKhaeLaMal3TCPVWb2a70u9AQxciZnN5CiAtnaI6wc5fMUwOdJ6WPB4Pp

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: operaciones_app; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA operaciones_app;


--
-- Name: configuracion; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.configuracion AS
 SELECT "FechaCorte" AS fecha_corte,
    '2025-01-01'::date AS fecha_inicio,
    'Extracción ERP / DW local'::text AS fuente,
    1 AS version_contrato
   FROM powerbi."Configuracion";


--
-- Name: actividad_conductores; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.actividad_conductores AS
 SELECT f.fecha,
    (m.conductor_id)::text AS conductor_id,
    sum(i.ingreso_estimado) AS ingreso,
    count(*) AS viajes,
    NULL::double precision AS km,
    NULL::double precision AS litros
   FROM (((ds_gestion.v_movimiento m
     JOIN comun.dim_fecha f ON ((f.sk_fecha = m.fecha_documental_id)))
     LEFT JOIN ds_gestion.v_ingreso_servicio i USING (movimiento_id))
     CROSS JOIN operaciones_app.configuracion c)
  WHERE ((NOT m.es_virtual) AND (m.conductor_id IS NOT NULL) AND ((f.fecha >= c.fecha_inicio) AND (f.fecha <= c.fecha_corte)))
  GROUP BY f.fecha, (m.conductor_id)::text;


--
-- Name: equipos; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.equipos AS
 SELECT equipo_id,
    patente,
    codigo,
    ((COALESCE(patente, 'Sin patente'::text) || ' '::text) || COALESCE(codigo, ''::text)) AS camion,
    marca,
    modelo,
    anio_fabricacion,
    estado_actual
   FROM taller.dim_equipo
  WHERE ((es_camion = 'S'::text) AND (estado_actual = 'O'::text) AND (marca IS NOT NULL));


--
-- Name: combustible_mes; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.combustible_mes AS
 SELECT m.periodo AS mes,
    e.equipo_id,
    e.camion,
    e.patente,
    e.codigo,
    e.marca,
    e.modelo,
    m.litros,
    m.km,
    m.km_gps,
    m.rendimiento,
    m.rendimiento_gps,
    m.calidad
   FROM ((gerencia_sql.camion_mes m
     JOIN operaciones_app.equipos e USING (equipo_id))
     CROSS JOIN operaciones_app.configuracion c)
  WHERE ((m.periodo >= c.fecha_inicio) AND (m.periodo <= c.fecha_corte));


--
-- Name: conductores; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.conductores AS
 SELECT (conductor_id)::text AS conductor_id,
    nombre_completo AS conductor,
    'Sin grupo comparable validado'::text AS grupo,
    'Real · DW'::text AS origen
   FROM dim_comun.dim_conductor
  WHERE (conductor_id IS NOT NULL);


--
-- Name: estado_diario; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.estado_diario AS
 SELECT e.equipo_id,
    e.camion,
    e.marca,
    e.modelo,
    d.fecha,
    (s.equipo_id IS NOT NULL) AS registro_presente,
    s.en_taller,
    s.con_viaje,
    s.horas_taller,
    s.viaje_estimado,
        CASE
            WHEN (s.equipo_id IS NULL) THEN 'Sin registro'::text
            WHEN (s.en_taller = 1) THEN 'Taller'::text
            WHEN (s.con_viaje = 1) THEN 'Viaje registrado'::text
            ELSE 'Disponible sin viaje registrado'::text
        END AS estado,
    (EXTRACT(day FROM (date_trunc('month'::text, (d.fecha)::timestamp with time zone) + '1 mon -1 days'::interval)))::integer AS dias_mes
   FROM ((((operaciones_app.equipos e
     CROSS JOIN operaciones_app.configuracion c)
     CROSS JOIN LATERAL ( SELECT (c.fecha_inicio + n.n) AS fecha
           FROM generate_series(0, (c.fecha_corte - c.fecha_inicio)) n(n)) d)
     LEFT JOIN comun.dim_fecha f ON ((f.fecha = d.fecha)))
     LEFT JOIN taller.fact_estado_diario_equipo s ON (((s.equipo_id = e.equipo_id) AND (s.sk_fecha = f.sk_fecha))));


--
-- Name: km_corredor; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.km_corredor AS
 WITH m AS (
         SELECT f.fecha,
            COALESCE(((m_1.origen || ' → '::text) || m_1.destino), 'Sin corredor'::text) AS corredor,
            m_1.km,
            m_1.vacio_fisico,
            (((m_1.km >= (0)::double precision) AND (m_1.km < 'Infinity'::double precision) AND (m_1.vacio_fisico = ANY (ARRAY['S'::text, 'N'::text])) AND (m_1.calidad_trayectoria = ANY (ARRAY['N'::text, 'NB'::text])) AND (NOT ((m_1.km = (0)::double precision) AND (m_1.origen IS DISTINCT FROM m_1.destino)))) IS TRUE) AS evaluable
           FROM (((ds_gestion.v_movimiento m_1
             JOIN comun.dim_fecha f ON ((f.sk_fecha = m_1.fecha_documental_id)))
             JOIN operaciones_app.equipos e USING (equipo_id))
             CROSS JOIN operaciones_app.configuracion c)
          WHERE ((NOT m_1.es_virtual) AND (m_1.tipo_operador = 'propio'::text) AND ((f.fecha >= c.fecha_inicio) AND (f.fecha <= c.fecha_corte)))
        )
 SELECT fecha,
    corredor,
    count(*) AS movimientos_alcance,
    count(*) FILTER (WHERE evaluable) AS movimientos_evaluables,
    sum(km) FILTER (WHERE evaluable) AS km_reales_evaluables,
        CASE
            WHEN (count(*) FILTER (WHERE evaluable) > 0) THEN COALESCE(sum(km) FILTER (WHERE (evaluable AND (vacio_fisico = 'S'::text))), (0)::double precision)
            ELSE NULL::double precision
        END AS km_vacios_reales
   FROM m
  GROUP BY fecha, corredor;


--
-- Name: ramplas; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.ramplas AS
 SELECT equipo_id,
    patente,
    codigo,
    ((COALESCE(patente, 'Sin patente'::text) || ' '::text) || COALESCE(codigo, ''::text)) AS rampla,
    categoria,
    marca,
    modelo,
    estado_actual
   FROM taller.dim_equipo
  WHERE (tipo_equipo = 'rampla'::text);


--
-- Name: relaciones_equipo; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.relaciones_equipo AS
 SELECT m.equipo_id,
    m.rampla_id,
    count(*) AS registros,
    min(f.fecha) AS primera_fecha,
    max(f.fecha) AS ultima_fecha
   FROM (((ds_gestion.v_movimiento m
     JOIN comun.dim_fecha f ON ((f.sk_fecha = m.fecha_documental_id)))
     JOIN operaciones_app.equipos e USING (equipo_id))
     CROSS JOIN operaciones_app.configuracion c)
  WHERE ((NOT m.es_virtual) AND ((f.fecha >= c.fecha_inicio) AND (f.fecha <= c.fecha_corte)) AND (m.rampla_id IS NOT NULL))
  GROUP BY m.equipo_id, m.rampla_id;


--
-- Name: retornos; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.retornos AS
 SELECT f.fecha,
    r.movimiento_id,
    r.nro_viaje,
    r.viaje_id,
    r.fecha_documental_id,
    r.mes_id,
    r.mes,
    r.origen,
    r.destino,
    r.corredor,
    r.cliente_id,
    r.cliente,
    r.producto_id,
    r.producto_nombre,
    r.tipo_operador,
    r.es_propio,
    r.ciclo_id,
    r.rol_comercial,
    r.vacio_fisico,
    r.equipo_id,
    r.equipo_nombre,
    r.conductor_nombre,
    r.alcance
   FROM ((ds_gestion.v_retorno r
     JOIN comun.dim_fecha f ON ((f.sk_fecha = r.fecha_documental_id)))
     CROSS JOIN operaciones_app.configuracion c)
  WHERE ((f.fecha >= c.fecha_inicio) AND (f.fecha <= c.fecha_corte));


--
-- Name: ventas_diarias; Type: VIEW; Schema: operaciones_app; Owner: -
--

CREATE VIEW operaciones_app.ventas_diarias AS
 SELECT v."Fecha" AS fecha,
    COALESCE(v."Cliente", 'Sin cliente'::text) AS cliente,
    COALESCE(v."TipoOperador", 'Sin clasificación'::text) AS operador,
    count(*) AS viajes,
    sum(v."Ingreso") AS ingreso,
    count(v."Ingreso") AS viajes_con_ingreso
   FROM (powerbi."Viajes" v
     CROSS JOIN operaciones_app.configuracion c)
  WHERE ((v."Fecha" >= c.fecha_inicio) AND (v."Fecha" <= c.fecha_corte))
  GROUP BY v."Fecha", COALESCE(v."Cliente", 'Sin cliente'::text), COALESCE(v."TipoOperador", 'Sin clasificación'::text);


--
-- PostgreSQL database dump complete
--

\unrestrict 7WaQqFOKhaeLaMal3TCPVWb2a70u9AQxciZnN5CiAtnaI6wc5fMUwOdJ6WPB4Pp


import pandas as pd
import streamlit as st
from core import ui,indicadores as calc
meta,periodo,fechas=ui.contexto();i,f,ip,fp=fechas
ui.cabecera('Actividad de conductores','Viajes e ingresos estimados asociados a identidades reales del ERP. La ruta y el trabajo asignado influyen en estos valores.')
ui.periodo_caption(fechas)
cat=ui.cargar('conductores');act=ui.cargar('actividad_conductores')
elegidos=st.multiselect('Buscar conductor',cat.conductor_id.tolist(),format_func=lambda x:cat.set_index('conductor_id').loc[x,'conductor'])
if elegidos:act=act[act.conductor_id.isin(elegidos)]
a=calc.filtrar(act,i,f);r=calc.filtrar(act,ip,fp)
c1,c2,c3=st.columns(3)
with c1:ui.metrica('Conductores con viajes',a.conductor_id.nunique(),r.conductor_id.nunique())
with c2:ui.metrica('Viajes asociados',a.viajes.sum() if not a.empty else None,r.viajes.sum() if not r.empty else None)
with c3:ui.metrica('Ingreso estimado asociado',a.ingreso.sum(min_count=1) if not a.empty else None,r.ingreso.sum(min_count=1) if not r.empty else None,prefijo='$ ',unidad=' CLP')
if a.empty:st.info('No hay actividad asociada a conductores en el período.')
else:
    g=a.groupby('conductor_id').agg(viajes=('viajes','sum'),ingreso=('ingreso',lambda x:x.sum(min_count=1)),dias_documentales=('fecha','nunique')).reset_index()
    g=g.merge(cat[['conductor_id','conductor']],on='conductor_id',how='left')
    ui.tabla(g[['conductor','viajes','ingreso','dias_documentales']].sort_values('ingreso',ascending=False).rename(columns={'conductor':'Conductor','viajes':'Viajes registrados','ingreso':'Ingreso estimado (CLP)','dias_documentales':'Días con viajes'}),'actividad_real_conductores')
st.caption('Los días documentales no son días trabajados personales ni duración física del viaje. No se presenta un ranking de productividad: los recorridos y las asignaciones no son equivalentes.')
with st.expander('Indicadores solicitados que requieren una fuente adicional'):
    st.write('Rendimiento real y esperado por conductor: falta una fuente que atribuya las cargas y el rendimiento a la persona de forma verificable. El consumo del camión no se atribuye automáticamente a su conductor.')
    st.write('Costo del conductor / venta: falta una fuente validada de costo total por persona y período. No se muestra sueldo ni desglose de remuneraciones.')
    st.write('Licencias, vacaciones, descansos y vencimientos documentales: sin una fuente validada. No se infieren del número de viajes.')

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from core import ui,indicadores as calc
meta,periodo,fechas=ui.contexto();i,f,ip,fp=fechas
ui.cabecera('Resumen de Operaciones','Actividad registrada, combustible y capacidad de la flota. Información histórica al corte del DW.')
ui.periodo_caption(fechas)
ventas=ui.cargar('ventas_diarias');diario=ui.cargar('estado_diario');comb=ui.cargar('combustible_mes')
a=calc.filtrar(ventas,i,f);r=calc.filtrar(ventas,ip,fp)
da=calc.resumen_dias(calc.filtrar(diario,i,f));dr=calc.resumen_dias(calc.filtrar(diario,ip,fp))
fuel=calc.combustible(comb[comb['mes'].eq(i)])
cols=st.columns(4)
with cols[0]:ui.metrica('Ingreso registrado',a['ingreso'].sum(min_count=1),r['ingreso'].sum(min_count=1),prefijo='$ ',unidad=' CLP')
with cols[1]:ui.metrica('Días disponibles',da['disponibles'],dr['disponibles'] if dr['base'] else None)
with cols[2]:ui.metrica('Días asociados a viajes',da['viaje'],dr['viaje'] if dr['base'] else None)
with cols[3]:ui.metrica('Rendimiento odómetro',fuel['rendimiento'],dec=2,unidad=' km/l')
st.caption('Ingreso: todos los operadores del ERP. Días y combustible: camiones O al corte. Ingreso no equivale a facturación, cobro ni margen.')
left,right=st.columns(2)
with left:
 st.subheader('Ingreso mensual por viajes')
 hist=ventas[ventas.fecha.dt.year.eq(i.year)].copy();hist['mes']=hist.fecha.dt.to_period('M').dt.to_timestamp()
 h=hist.groupby('mes',as_index=False)['ingreso'].sum(min_count=1)
 h=h[h.mes+pd.offsets.MonthEnd(0)<=meta.fecha_corte]
 ui.grafico(go.Figure(go.Bar(x=h.mes,y=h.ingreso,marker_color=ui.ROJO,name='Ingreso ERP')),moneda='y')
with right:
 st.subheader('Días del período')
 labels=['Asociados a viajes','Disponibles sin viaje','Taller','Sin registro']
 vals=[da['viaje'],da['sin_viaje'],da['taller'],da['sin_registro']]
 fig=go.Figure(go.Bar(x=labels,y=vals,marker_color=[ui.VERDE,ui.NEGRO,ui.ROJO,'#A6A4A3']))
 ui.grafico(fig)
st.subheader('Qué revisar')
if da['sin_registro']:st.warning(f"Hay {ui.numero(da['sin_registro'])} días-camión sin registro diario: no se cuentan como disponibles ni como taller. Falta la fila diaria en el DW; no significa que el camión estuviera detenido.")
st.info('Los días asociados a viajes provienen de registros documentales; no acreditan tiempos reales en ruta. La ausencia de viaje registrado tampoco demuestra inactividad.')
ui.aviso_poblacion()
st.caption('Las tendencias muestran meses completos. No se informa ubicación actual ni disponibilidad en tiempo real.')

import streamlit as st
import pandas as pd
from core import ui,indicadores as calc
meta,periodo,fechas=ui.contexto();i,f,ip,fp=fechas
ui.cabecera('Recorridos y retornos','Revisión histórica de distancias de tramo y mezcla de operadores. No identifica cargas disponibles ni asigna viajes.')
ui.periodo_caption(fechas)
km=calc.filtrar(ui.cargar('km_corredor'),i,f)
ret=calc.filtrar(ui.cargar('retornos'),i,f)
opciones=sorted(set(km.corredor.dropna())|set(ret.corredor.dropna()))
corredores=st.multiselect('Corredores',opciones,placeholder='Todos los corredores')
if corredores:km=km[km.corredor.isin(corredores)];ret=ret[ret.corredor.isin(corredores)]
st.subheader('Kilómetros vacíos')
total=km.km_reales_evaluables.sum(min_count=1);vacio=km.km_vacios_reales.sum(min_count=1)
c1,c2,c3=st.columns(3)
with c1:ui.metrica('Km vacíos evaluables',vacio,dec=0,unidad=' km')
with c2:ui.metrica('Distancia vacía / evaluable',100*vacio/total if pd.notna(total) and total>0 else None,dec=1,unidad='%')
with c3:ui.metrica('Cobertura de kilómetros',100*km.movimientos_evaluables.sum()/km.movimientos_alcance.sum() if km.movimientos_alcance.sum() else None,dec=1,unidad='%')
if not km.empty:
    g=km.groupby('corredor')[['movimientos_alcance','movimientos_evaluables','km_reales_evaluables','km_vacios_reales']].sum(min_count=1).reset_index().sort_values('km_vacios_reales',ascending=False)
    ui.tabla(g.rename(columns={'corredor':'Corredor','movimientos_alcance':'Movimientos propios','movimientos_evaluables':'Evaluables','km_reales_evaluables':'Km evaluables','km_vacios_reales':'Km vacíos'}),'km_corredor')
st.caption('Alcance: movimientos reales propios de camiones con estado O al corte. El informe del compañero incluye todos los propios; sus totales pueden ser mayores. Distancia de tramo, no odómetro ni GPS. Se excluyen virtuales, distancia negativa/no finita, condición de carga desconocida, trayectoria distinta de N/NB y cero km entre ciudades distintas. Un vacío puede ser necesario.')
st.subheader('Retornos registrados · todos los operadores')
clientes=st.multiselect('Cliente del retorno · solo afecta este panel',sorted(ret.cliente.dropna().unique()))
if clientes:ret=ret[ret.cliente.isin(clientes)]
g=ret.groupby(['cliente','tipo_operador'],dropna=False).size().rename('Retornos').reset_index()
propios=ret.tipo_operador.eq('propio').sum();conocidos=ret.tipo_operador.isin(['propio','fletero','caterina']).sum()
c1,c2=st.columns(2)
with c1:ui.metrica('Retornos registrados',len(ret))
with c2:ui.metrica('Retornos propios (%)',100*propios/conocidos if conocidos else None,dec=1,unidad='%')
if not g.empty:ui.tabla(g.rename(columns={'cliente':'Cliente','tipo_operador':'Operador'}),'retornos_operadores')
st.caption('Retornos propios (%) = retornos propios / retornos con operador propio, fletero o Caterina. Los operadores sin clasificación quedan fuera del denominador. Clasificación comercial Retorno del ERP. La coincidencia mensual de terceros y vacíos no demuestra simultaneidad ni una oportunidad de carga perdida. El cliente del retorno no filtra los km vacíos.')

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from core import ui,indicadores as calc
meta,periodo,fechas=ui.contexto();i,f,ip,fp=fechas
ui.cabecera('Ventas por cliente','Ingreso registrado del ERP. Incluye todos los operadores registrados; no representa cobros ni margen.')
ui.periodo_caption(fechas)
d=ui.cargar('ventas_diarias')
c1,c2=st.columns([2,1])
clientes=c1.multiselect('Clientes',sorted(d.cliente.unique()),placeholder='Todos los clientes')
operadores=c2.multiselect('Operadores',sorted(d.operador.unique()),placeholder='Todos los operadores')
if clientes:d=d[d.cliente.isin(clientes)]
if operadores:d=d[d.operador.isin(operadores)]
a=calc.filtrar(d,i,f);r=calc.filtrar(d,ip,fp)
if a.empty:st.info('No hay viajes para esta selección.');st.stop()
va=a.ingreso.sum(min_count=1);vr=r.ingreso.sum(min_count=1)
na=a.viajes.sum();nr=r.viajes.sum() if not r.empty else None
cols=st.columns(3)
with cols[0]:ui.metrica('Ingreso registrado',va,vr,prefijo='$ ',unidad=' CLP')
with cols[1]:ui.metrica('Viajes registrados',na,nr)
with cols[2]:ui.metrica('Ingreso medio por viaje',va/a.viajes_con_ingreso.sum() if a.viajes_con_ingreso.sum() else None,vr/r.viajes_con_ingreso.sum() if not r.empty and r.viajes_con_ingreso.sum() else None,prefijo='$ ',unidad=' CLP')
if a.viajes_con_ingreso.sum()<na:st.warning('Existen viajes sin ingreso informado. No se imputan como ingreso cero; el promedio usa solo viajes con ingreso.')
pc=a.groupby('cliente')[['ingreso','viajes']].sum(min_count=1).join(r.groupby('cliente').ingreso.sum(min_count=1).rename('referencia'),how='outer')
pc['variacion']=pc['ingreso']-pc['referencia'];pc=pc.reset_index().sort_values('ingreso',ascending=False)
st.subheader('Comparación por cliente')
top=pc.head(12).sort_values('ingreso');fig=go.Figure()
fig.add_bar(y=top.cliente,x=top.referencia,orientation='h',name='Mes anterior · comparable',marker_color=ui.NEGRO)
fig.add_bar(y=top.cliente,x=top.ingreso,orientation='h',name='Período seleccionado',marker_color=ui.ROJO)
fig.update_layout(barmode='group');ui.grafico(fig,moneda='x')
ui.tabla(pc.rename(columns={'cliente':'Cliente','ingreso':'Ingreso (CLP)','referencia':'Mes anterior (CLP)','viajes':'Viajes','variacion':'Diferencia (CLP)'}),'ventas_clientes')
st.caption('Sin metas inventadas. Una referencia vacía significa que no hay registro para esa selección; no se fuerza una variación porcentual.')

st.caption('Moneda: pesos chilenos (CLP), sin decimales. El promedio considera únicamente viajes con ingreso informado.')

import streamlit as st
from core import ui,ilustrativos as demo
meta,periodo,fechas=ui.contexto()
ui.cabecera('Ramplas y dimensiones','Catálogo real de equipos con dimensiones interiores ilustrativas para mostrar la información que necesita Operaciones.',True)
st.warning('Las dimensiones son simuladas. No se deben utilizar para confirmar capacidad, compatibilidad ni aceptar una carga real.')
d=demo.dimensiones(ui.cargar('ramplas'))
c1,c2,c3=st.columns([2,1,1])
busca=c1.text_input('Buscar patente o código de rampla')
cat=c2.multiselect('Categoría del DW',sorted(d.categoria.dropna().unique()),placeholder='Todas')
solo=c3.checkbox('Solo estado O del catálogo',value=True)
if busca:d=d[d.rampla.str.contains(busca.strip(),case=False,regex=False)]
if cat:d=d[d.categoria.isin(cat)]
if solo:d=d[d.estado_actual.eq('O')]
c1,c2=st.columns(2)
with c1:ui.metrica('Ramplas en la consulta',len(d))
with c2:ui.metrica('Dimensiones verificadas',0)
st.caption('Patente, código, categoría y estado: DW real al corte. Largo, ancho y alto: ilustrativos; no se han medido.')
ui.tabla(d[['rampla','categoria','estado_actual','largo_interior_m','ancho_interior_m','alto_interior_m','origen_dimensiones']].rename(columns={'rampla':'Rampla','categoria':'Categoría','estado_actual':'Estado al corte','largo_interior_m':'Largo (m)','ancho_interior_m':'Ancho (m)','alto_interior_m':'Alto (m)','origen_dimensiones':'Origen de dimensiones'}),'ramplas_dimensiones')
with st.expander('Relaciones históricas camión–rampla registradas en el DW'):
 st.caption('Son combinaciones observadas en registros históricos. No prueban una asociación habitual ni vigente; no se inventan parejas conductor–camión.')
 rel=ui.cargar('relaciones_equipo');equipos=ui.cargar('equipos')
 rel=rel.merge(equipos[['equipo_id','camion']],on='equipo_id',validate='many_to_one').merge(d[['equipo_id','rampla']],left_on='rampla_id',right_on='equipo_id',suffixes=('','_rampla'),validate='many_to_one')
 ui.tabla(rel[['camion','rampla','registros','primera_fecha','ultima_fecha']].sort_values('ultima_fecha',ascending=False).rename(columns={'camion':'Camión','rampla':'Rampla','registros':'Registros históricos','primera_fecha':'Primera fecha','ultima_fecha':'Última fecha'}),'relaciones_historicas')

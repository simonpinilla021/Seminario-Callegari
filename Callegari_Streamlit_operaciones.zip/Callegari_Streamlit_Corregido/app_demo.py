"""Entrada exclusiva de demostración para compartir sin acceso al DW."""
import os
from pathlib import Path
os.environ['CALLEGARI_SOLO_DEMO']='1'
exec(compile((Path(__file__).parent/'app.py').read_text(encoding='utf8'),str(Path(__file__).parent/'app.py'),'exec'))

"""Dashboard exclusivo del jefe de Operaciones. No asigna ni programa servicios."""
import streamlit as st
from core.auth import cerrar_sesion, pagina_acceso, usuario_actual
from core import dw,ui,demo
st.set_page_config(page_title="Operaciones · Callegari",page_icon=str(ui.LOGO),layout="wide")
ui.estilo()
if demo.solo_demo():
    st.session_state.update(modo_demo=True,usuario='demo',nombre_usuario='Visitante de demostración',rol='operaciones')
if not usuario_actual():
    if st.button('Ver demostración', type='primary', icon=':material/visibility:'):
        st.session_state.update(modo_demo=True,usuario='demo',nombre_usuario='Visitante de demostración',rol='operaciones',perfil_dw='demo')
        st.rerun()
    st.caption('Explora el tablero con datos ficticios, sin credenciales ni conexión al DW.')
if demo.activa():
    st.warning('Demostración · Datos ficticios. Ningún indicador, cliente, equipo o conductor representa información real de Callegari. No hay conexión al DW.')
if not usuario_actual():
    st.navigation([st.Page(pagina_acceso,title="Acceso",icon=":material/lock:")],position="hidden").run()
    st.stop()
if st.session_state.get('rol') not in {'operaciones','jefe_operaciones'}:
    st.error('Este tablero es exclusivo del jefe de Operaciones. Su usuario no tiene acceso.')
    if st.button('Cerrar sesión'):cerrar_sesion()
    st.stop()
st.logo(str(ui.LOGO),size='large')
pg=st.navigation({'Jefe de Operaciones':[
 st.Page('vistas/operaciones/resumen.py',title='Resumen',icon=':material/dashboard:',default=True),
 st.Page('vistas/operaciones/ingresos.py',title='Ventas por cliente',icon=':material/receipt_long:'),
 st.Page('vistas/operaciones/conductores.py',title='Actividad de conductores',icon=':material/groups:'),
 st.Page('vistas/operaciones/recorridos.py',title='Recorridos y retornos',icon=':material/route:'),
 st.Page('vistas/operaciones/combustible.py',title='Combustible',icon=':material/local_gas_station:'),
 st.Page('vistas/operaciones/disponibilidad.py',title='Disponibilidad',icon=':material/calendar_month:'),
 st.Page('vistas/operaciones/restricciones.py',title='Conductores y bloqueos',icon=':material/badge:'),
 st.Page('vistas/operaciones/ramplas.py',title='Ramplas',icon=':material/local_shipping:'),
 st.Page('vistas/operaciones/conexion.py',title='Datos y conexión',icon=':material/database:'),
]})
with st.sidebar:
    st.caption('VISUALIZACIÓN DE OPERACIONES')
    cfg=dw.perfiles();opciones=list(cfg['perfiles'])
    if st.session_state.get('perfil_dw') not in opciones:st.session_state['perfil_dw']=cfg.get('perfil_predeterminado',opciones[0])
    st.selectbox('Conexión',opciones,key='perfil_dw',format_func=lambda x:cfg['perfiles'][x].get('etiqueta',x))
    try:
        meta=dw.metadatos();periodos=ui.periodos(meta)
        if st.session_state.get('periodo') not in periodos:st.session_state['periodo']='2026-01' if '2026-01' in periodos else periodos[-1]
        st.selectbox('Período de los indicadores',periodos,key='periodo',format_func=ui.nombre_periodo)
        st.caption(f"Corte de los datos: {meta.fecha_corte:%d/%m/%Y}")
        st.caption('Comparación: mes anterior, hasta el mismo día cuando el mes está incompleto.')
    except dw.ErrorDW as e:st.warning(str(e))
    if st.button('Recargar datos ficticios' if demo.activa() else 'Actualizar desde el DW',icon=':material/refresh:',width='stretch'):
        dw.actualizar();st.rerun()
    st.divider()
    st.caption('Todos los datos son ficticios.' if demo.activa() else 'Datos reales: indicadores y conductores del DW. Complementos ilustrativos: dimensiones de ramplas y bloqueos por cliente.')
    st.caption(f"Sesión: {st.session_state.get('nombre_usuario','Jefe de Operaciones')}")
    if not demo.solo_demo():
        if st.button('Salir de la demostración' if demo.activa() else 'Cerrar sesión',icon=':material/logout:',width='stretch'):cerrar_sesion()
pg.run()

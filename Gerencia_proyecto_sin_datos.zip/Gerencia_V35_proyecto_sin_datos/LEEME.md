# Informe Gerencia V35

Proyecto de Power BI con el diseño del informe y el modelo, sin registros empresariales.

Para revisar el diseño, extraer el ZIP y abrir Gerencia_V35_GitHub.pbip en Power BI Desktop. Mantener juntas las carpetas Report y SemanticModel con el archivo PBIP.

Los indicadores aparecen vacíos hasta que se configuren las fuentes y se actualicen los datos. Se conservan los catálogos y selectores del informe.

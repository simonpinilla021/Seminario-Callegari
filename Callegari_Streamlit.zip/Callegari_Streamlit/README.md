# Callegari · Jefe de Operaciones

Aplicación Streamlit con nueve páginas: resumen, ventas por cliente, actividad de conductores, recorridos y retornos, combustible, disponibilidad, conductores y bloqueos, ramplas y conexión.

## Requisitos

- Python 3.11 o superior.
- PostgreSQL accesible con el esquema `operaciones_app` y sus vistas. El repositorio contiene la aplicación, no una copia del DW ni de los datos de la empresa.

## Instalación en Windows

Ejecutar desde esta carpeta:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item conexion.ejemplo.toml conexion.toml
Copy-Item .streamlit/secrets_ejemplo.toml .streamlit/secrets.toml
.\.venv\Scripts\python.exe generar_clave.py
```

Editar `conexion.toml` con los datos de PostgreSQL. En `.streamlit/secrets.toml`, pegar el hash generado en `clave_hash` y configurar el usuario de acceso. La contraseña de PostgreSQL puede configurarse en `[dw.local]` o `[dw.empresa]`, según el perfil, con la clave `password`; también se admite `CALLEGARI_DW_PASSWORD`, `CALLEGARI_DW_PASSWORD_LOCAL`, `CALLEGARI_DW_PASSWORD_EMPRESA` o pgpass.

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

También se puede usar `Iniciar_Operaciones.cmd` una vez instalado y configurado.

## Contrato de datos

`sql/operaciones_app.sql` define las vistas de lectura que espera la aplicación sobre un DW existente. Revisar sus fuentes con el administrador de PostgreSQL antes de instalarlo; no crea ni carga el DW completo. Usar un usuario con permisos de lectura.

Los indicadores y conductores proceden del DW. Las dimensiones de ramplas y los bloqueos por cliente son complementos ilustrativos; sus cambios se almacenan en `datos_locales/`, que se genera durante el uso.

## GitHub

Subir el contenido de esta carpeta como raíz del repositorio. Se excluyeron los entornos Python, credenciales reales, bases locales, registros, respaldos y documentos históricos. `.gitignore` excluye la configuración privada y los datos que se generen posteriormente. No incluirlos al cargar archivos manualmente en GitHub.

El archivo de entrada es `app.py`. Para ejecutar en otro equipo o servidor hay que instalar las dependencias, configurar los secretos y disponer de conexión al DW. Esta copia no depende de las carpetas de la entrega original.

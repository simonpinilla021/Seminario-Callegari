from pathlib import Path
import hashlib,json,html
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from core import dw,indicadores as calc
from core.formato import fmt_num,MESES
LOGO=Path(__file__).resolve().parents[1]/'assets/logo.jpg'
ROJO='#F21F2D';VERDE='#1E9D51';NEGRO='#201C19';GRIS='#EBECEA'
def estilo():
 st.markdown('''<style>
 .block-container{padding-top:1.8rem;padding-bottom:2rem;max-width:1600px}
 h1{font-size:2rem!important;letter-spacing:-.5px} h2{font-size:1.35rem!important}
 [data-testid="stSidebar"]{border-right:1px solid #EBECEA}
 [data-testid="stSidebar"] [data-testid="stLogo"]{height:115px;object-fit:contain}
 [data-testid="stMetricValue"]{font-size:1.8rem} [data-testid="stMetricLabel"]{font-size:.9rem}
 div[data-testid="stVerticalBlockBorderWrapper"]{border-radius:12px}
 .etiqueta{display:inline-block;padding:4px 10px;border-radius:5px;background:#EBECEA;font-size:.8rem;margin:0 6px 6px 0}
 </style>''',unsafe_allow_html=True)
def cabecera(titulo,subtitulo,ilustrativo=False):
 st.caption('TRANSPORTES CALLEGARI / JEFE DE OPERACIONES')
 st.title(titulo);st.write(subtitulo)
 st.markdown('<span class="etiqueta">'+('Complementos ilustrativos' if ilustrativo else 'Datos reales · DW')+'</span>',unsafe_allow_html=True)
def periodos(meta):return [str(p) for p in pd.period_range(meta.fecha_inicio,meta.fecha_corte,freq='M')]
def nombre_periodo(p):
 x=pd.Period(p,freq='M');return f'{MESES[x.month-1]} {x.year}'
def contexto():
 try:
  meta=dw.metadatos();periodo=st.session_state.get('periodo','2026-01')
  return meta,periodo,calc.ventanas_comparables(periodo,meta.fecha_corte)
 except dw.ErrorDW as e:st.error(str(e));st.stop()
def cargar(tabla):
 try:return dw.leer(tabla)
 except dw.ErrorDW as e:st.error(str(e));st.stop()
def periodo_caption(fechas):
 i,f,ip,fp=fechas
 st.caption(f'Período: {i:%d/%m/%Y}–{f:%d/%m/%Y} · Comparación: {ip:%d/%m/%Y}–{fp:%d/%m/%Y}.')
def numero(v,dec=0):return '—' if v is None or pd.isna(v) else fmt_num(v,dec)
def metrica(titulo,valor,ref=None,dec=0,prefijo='',unidad=''):
 with st.container(border=True):
  v='—' if valor is None or pd.isna(valor) else f'{prefijo}{numero(valor,dec)}{unidad}'
  delta=None if ref is None or pd.isna(ref) or valor is None or pd.isna(valor) else f'{numero(valor-ref,dec)}{unidad} vs mes anterior'
  st.metric(titulo,v,delta=delta,delta_color='off')
  if ref is not None and not pd.isna(ref):st.caption(f'Referencia: {prefijo}{numero(ref,dec)}{unidad}')
def grafico(fig,moneda=None):
 fig.update_layout(template='plotly_white',font=dict(family='Segoe UI',color=NEGRO,size=13),colorway=[ROJO,VERDE,NEGRO],margin=dict(l=10,r=15,t=35,b=10),legend=dict(orientation='h',y=1.13),height=350,separators=',.')
 if moneda:
  getattr(fig,'update_'+moneda+'axes')(tickformat=',.0f',tickprefix='$ ',ticksuffix=' CLP')
  fig.update_traces(hovertemplate=('%{y}<br>$ %{x:,.0f} CLP<extra>%{fullData.name}</extra>' if moneda=='x' else '%{x}<br>$ %{y:,.0f} CLP<extra>%{fullData.name}</extra>'))
 st.plotly_chart(fig,width='stretch',config={'displaylogo':False})
def formato_columna(nombre):
 n=str(nombre).lower()
 if any(x in n for x in ['ingreso','diferencia','clp','($)']):return lambda x:'—' if pd.isna(x) else '$ '+fmt_num(x,0)+' CLP'
 if any(x in n for x in ['km','litros','rendimiento']):return lambda x:numero(x,2)
 return lambda x:numero(x,2 if pd.notna(x) and x%1 else 0)

def tabla(df,nombre='detalle',height=420):
 formatos={c:formato_columna(c) for c in df.select_dtypes(include='number').columns}
 st.dataframe(df.style.format(formatos,na_rep='—'),hide_index=True,width='stretch',height=height)
 # Evitar fórmulas al abrir CSV exportados en Excel.
 safe=df.copy()
 for c in safe.select_dtypes(include=['object','string']):safe[c]=safe[c].map(lambda x:"'"+x if isinstance(x,str) and x.startswith(('=','+','-','@')) else x)
 st.download_button('Descargar tabla CSV',safe.to_csv(index=False).encode('utf-8-sig'),file_name=nombre+'.csv',mime='text/csv',key='export_'+nombre)
def filtro_camiones(df,key):
 etiquetas=sorted(df['camion'].dropna().unique())
 sel=st.multiselect('Camión · buscar patente o código',etiquetas,key=key,placeholder='Todos los camiones O al corte')
 return df[df['camion'].isin(sel)].copy() if sel else df.copy()
def entorno():
 p=st.session_state.get('perfil_dw','local');d=dw.configuracion_perfil(p)
 return hashlib.sha256(json.dumps({k:d[k] for k in ['host','port','dbname','schema']},sort_keys=True).encode()).hexdigest()[:20]
def aviso_poblacion():st.caption('Camiones con estado O al corte de la extracción. No existe un historial fiable de ese estado; no acredita que fueran operativos en cada mes anterior.')

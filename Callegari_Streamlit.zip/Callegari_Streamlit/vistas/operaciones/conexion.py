import pandas as pd
import streamlit as st
from core import dw,ui
ui.cabecera('Datos y conexión','Origen de la información, fecha de corte y configuración para el DW local o de la empresa.')
perfil=st.session_state.get('perfil_dw','local');cfg=dw.configuracion_perfil(perfil)
st.subheader('Conexión seleccionada')
st.dataframe(pd.DataFrame({'Campo':['Perfil','Servidor','Puerto','Base de datos','Esquema','SSL'],'Valor':[perfil,cfg['host'],str(cfg['port']),cfg['dbname'],cfg['schema'],cfg['sslmode']]}),hide_index=True,width='stretch')
try:
 meta=dw.metadatos();st.success(f'Conexión disponible · contrato {int(meta.version_contrato)} · corte {meta.fecha_corte:%d/%m/%Y}.')
except dw.ErrorDW as e:st.error(str(e))
if st.button('Comprobar las tablas del contrato'):
 try:
  dw.actualizar();rows=[{'Tabla':t,'Filas consultadas':len(dw.leer(t))} for t in sorted(dw.TABLAS)]
  st.dataframe(rows,hide_index=True,width='stretch');st.success('Todas las tablas del contrato responden.')
 except dw.ErrorDW as e:st.error(str(e))
st.subheader('Cambiar a la conexión de la empresa')
st.write('1. Completar un perfil de empresa en conexion.toml con los datos que entregue TI, usando conexion.ejemplo.toml como referencia.\n2. Mantener el mismo contrato de vistas o adaptar su SQL a las fuentes de la empresa.\n3. Configurar la contraseña fuera del código.\n4. Seleccionar el perfil en el menú lateral y comprobar las tablas.')
with st.expander('Configuración de ejemplo · sin credenciales'):
 st.code((dw.RAIZ/'conexion.ejemplo.toml').read_text(encoding='utf8'),language='toml')
 st.caption('La contraseña puede venir del archivo pgpass, de CALLEGARI_DW_PASSWORD_EMPRESA o de [dw.empresa] password en .streamlit/secrets.toml. No se muestra ni se edita en este dashboard.')
st.subheader('Qué es real y qué es ilustrativo')
st.dataframe(pd.DataFrame([
 {'Contenido':'Ingresos, viajes, equipos, combustible y registros diarios','Origen':'DW real','Límite':'Extracción al corte; no tiempo real'},
 {'Contenido':'Identidades de conductores','Origen':'Catálogo real dim_comun del DW actualizado','Límite':'Actividad documental; no acredita descanso, licencia ni disponibilidad personal'},
 {'Contenido':'Dimensiones de ramplas','Origen':'Ilustrativo','Límite':'No son mediciones ni garantías de compatibilidad'},
 {'Contenido':'Bloqueos por conductor y cliente','Origen':'Ilustrativo · registro SQLite local editable','Límite':'No son habilitaciones ni restricciones reales'},
 {'Contenido':'Relaciones camión–rampla','Origen':'Registros históricos reales','Límite':'No son asignaciones actuales'},
]),hide_index=True,width='stretch')
st.caption('Las consultas al DW son de solo lectura, con caché de 5 minutos y actualización manual. Actualizar la consulta no actualiza la extracción ERP. Las ediciones ilustrativas persisten localmente y se separan por servidor/base/esquema.')

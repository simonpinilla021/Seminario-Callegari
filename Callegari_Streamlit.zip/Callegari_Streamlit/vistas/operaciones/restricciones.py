from datetime import date
import pandas as pd
import streamlit as st
from core import ui,ilustrativos as demo,indicadores as calc
meta,periodo,fechas=ui.contexto()
ui.cabecera('Conductores y bloqueos','Consulta de restricciones ilustrativas. La edición modifica únicamente el registro local de demostración.',True)
catalogo_real=ui.cargar('conductores');actividad=ui.cargar('actividad_conductores')
catalogo=catalogo_real if not catalogo_real.empty else demo.CONDUCTORES.copy()
if catalogo_real.empty:
 st.warning('El catálogo de conductores del DW está vacío. Se muestran 12 identidades ficticias; no representan trabajadores de Callegari ni tienen ventas o consumos reales atribuidos.')
else:st.info('Identidades reales del DW. Los bloqueos de esta pantalla siguen siendo ilustrativos y no acreditan restricciones de estas personas.')
clientes=sorted(ui.cargar('ventas_diarias').cliente.unique().tolist());entorno=ui.entorno()
demo.sembrar(entorno,catalogo,clientes);bloqueos=demo.leer(entorno)
consulta,editor,actividad_tab=st.tabs(['Consultar bloqueos','Agregar o editar','Sobre los conductores'])
with consulta:
 c1,c2,c3=st.columns([2,2,1])
 cliente=c1.selectbox('Cliente a consultar',['Todos']+clientes)
 conductor=c2.selectbox('Conductor a consultar',['Todos']+catalogo.conductor_id.tolist(),format_func=lambda x:x if x=='Todos' else catalogo.set_index('conductor_id').loc[x,'conductor'])
 fecha=c3.date_input('Vigentes al',date.today())
 solo=st.checkbox('Solo restricciones activas y vigentes',value=True)
 b=demo.vigentes(bloqueos,fecha) if solo else bloqueos.copy()
 if cliente!='Todos':b=b[b.cliente.eq(cliente)]
 if conductor!='Todos':b=b[b.conductor_id.eq(conductor)]
 st.caption('Bloqueos ilustrativos por conductor y cliente. No tener un bloqueo registrado no confirma habilitación, descanso ni disponibilidad para trabajar.')
 if b.empty:st.info('No hay restricciones registradas para esta consulta.')
 else:
  b=b.merge(catalogo[['conductor_id','conductor']],on='conductor_id',how='left')
  b['conductor']=b.conductor.fillna('Identidad no presente en el catálogo de esta conexión')
  b['Origen']='Ilustrativo'
  ui.tabla(b[['id','conductor','cliente','motivo','desde','hasta','activo','Origen']].rename(columns={'id':'Registro','conductor':'Conductor','cliente':'Cliente','motivo':'Motivo simulado','desde':'Desde','hasta':'Hasta','activo':'Activo'}),'bloqueos_ilustrativos')
with editor:
 if st.session_state.pop('bloqueo_desactivado',False):st.success('Bloqueo desactivado. Se conserva su historial y deja de figurar como activo.')
 st.info('Todos los registros creados o editados aquí son ilustrativos. No se transmiten al ERP ni al DW.')
 ids=[None]+bloqueos.id.tolist()
 elegido=st.selectbox('Registro',ids,format_func=lambda x:'Nuevo bloqueo ilustrativo' if x is None else f'Registro {x}')
 row=None if elegido is None else bloqueos[bloqueos.id.eq(elegido)].iloc[0]
 if row is not None:
  if row.activo:
   if st.button('Desactivar bloqueo',key='desactivar_bloqueo'):
    try:
     demo.desactivar(entorno,elegido,st.session_state.get('usuario',''))
     st.session_state['bloqueo_desactivado']=True;st.rerun()
    except ValueError as e:st.error(str(e))
  else:st.caption('Este bloqueo está inactivo. Puedes reactivarlo marcando «Activo» y guardando.')
 opciones=catalogo.conductor_id.tolist()
 if row is not None and row.conductor_id not in opciones:
  st.warning('La identidad de este registro ya no está en el catálogo. Seleccione una identidad vigente al editar.')
 def idx(vals,x):return vals.index(x) if x in vals else 0
 with st.form('editar_bloqueo',clear_on_submit=False):
  c1,c2=st.columns(2)
  cond=c1.selectbox('Conductor',opciones,index=idx(opciones,row.conductor_id) if row is not None else 0,format_func=lambda x:catalogo.set_index('conductor_id').loc[x,'conductor'])
  cli=c2.selectbox('Cliente',clientes,index=idx(clientes,row.cliente) if row is not None else 0)
  motivo=st.text_area('Motivo ilustrativo',value=row.motivo if row is not None else '',max_chars=500)
  c1,c2=st.columns(2)
  desde=c1.date_input('Válido desde',pd.Timestamp(row.desde).date() if row is not None else date.today())
  tiene_fin=c2.checkbox('Tiene fecha de término',value=row is not None and pd.notna(row.hasta))
  hasta=c2.date_input('Válido hasta',pd.Timestamp(row.hasta).date() if row is not None and pd.notna(row.hasta) else date.today())
  activo=st.checkbox('Activo',value=bool(row.activo) if row is not None else True,help='Desmarcar para desactivar sin borrar el historial.')
  guardar=st.form_submit_button('Guardar registro ilustrativo',type='primary')
 if guardar:
  try:
   demo.guardar(entorno,cond,cli,motivo,desde,hasta if tiene_fin else None,activo,st.session_state.get('usuario',''),id=elegido)
   st.session_state['bloqueo_guardado']=True;st.rerun()
  except ValueError as e:st.error(str(e))
 if st.session_state.pop('bloqueo_guardado',False):st.success('Registro ilustrativo guardado. El cambio persiste al cerrar y volver a abrir el tablero.')
with actividad_tab:
 st.info('La actividad real por conductor está en la página «Actividad de conductores». Las restricciones de esta página son ilustrativas.')

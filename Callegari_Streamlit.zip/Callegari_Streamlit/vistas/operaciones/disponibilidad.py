import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from core import ui,indicadores as calc
meta,periodo,fechas=ui.contexto();i,f,ip,fp=fechas
ui.cabecera('Disponibilidad','Días brutos de la flota, separados entre taller, viajes registrados y falta de cobertura.')
ui.periodo_caption(fechas);ui.aviso_poblacion()
d=ui.filtro_camiones(ui.cargar('estado_diario'),'dias_camiones')
modo=st.radio('Base de días',['Calendario real','Base 30 · días equivalentes'],horizontal=True)
norm=modo.startswith('Base 30');a=calc.filtrar(d,i,f);r=calc.filtrar(d,ip,fp)
v=calc.resumen_dias(a,norm);ref=calc.resumen_dias(r,norm)
cols=st.columns(4)
for col,key,title in zip(cols,['disponibles','viaje','taller','sin_viaje'],['Días disponibles','Asociados a viajes','Días en taller','Disponibles sin viaje']):
 with col:ui.metrica(title,v[key],ref[key] if ref['base'] else None,dec=1 if norm else 0)
st.caption(f"Base: {ui.numero(v['base'],1 if norm else 0)} días-camión · Sin registro: {ui.numero(v['sin_registro'],1 if norm else 0)} · Taller y viaje coincidentes: {ui.numero(v['solapados'],1 if norm else 0)}.")
if norm:st.info('Días equivalentes = días registrados × 30 / días reales del mes. Se aplica el mismo factor a todos los componentes; no se extrapola un mes parcial.')
if v['sin_registro']:st.warning('Los días sin registro se mantienen separados; no se cuentan como disponibles ni como taller. Falta la fila diaria en el DW; no significa que el camión estuviera detenido. No podemos reconstruir el estado operativo histórico.')
with st.expander('Definiciones y porcentajes de referencia'):
 st.write('Base = disponibles + taller + sin registro. Disponibles = asociados a viajes + disponibles sin viaje registrado.')
 st.write('Taller: umbral de 8 horas/día del DW; prevalece sobre viaje para evitar contar el mismo día dos veces. No representa horas exactas de indisponibilidad.')
 st.write(f"Disponibilidad registrada / base: {ui.numero(v['disponibilidad_pct'],1)} %. Días con viaje / disponibles: {ui.numero(v['uso_registrado_pct'],1)} %.")
 st.write(f"Días con viaje estimado en origen: {ui.numero(v['viaje_estimado'],1 if norm else 0)}. Las fechas documentales no demuestran permanencia física en ruta.")
st.subheader('Calendario diario')
estado={'Disponible sin viaje registrado':0,'Viaje registrado':1,'Taller':2,'Sin registro':3}
p=a.assign(dia=a.fecha.dt.day,codigo=a.estado.map(estado)).pivot(index='camion',columns='dia',values='codigo').sort_index()
if not p.empty:
 fig=go.Figure(go.Heatmap(z=p.values,x=p.columns,y=p.index,zmin=0,zmax=3,showscale=False,xgap=1,ygap=1,
 colorscale=[[0,ui.GRIS],[.16,ui.GRIS],[.17,ui.VERDE],[.49,ui.VERDE],[.50,ui.ROJO],[.83,ui.ROJO],[.84,'#A6A4A3'],[1,'#A6A4A3']],
 text=a.assign(dia=a.fecha.dt.day).pivot(index='camion',columns='dia',values='estado').reindex(p.index).values,
 hovertemplate='%{y} · día %{x}<br>%{text}<extra></extra>'))
 fig.update_layout(height=min(1300,max(350,len(p)*22)),yaxis=dict(autorange='reversed'),xaxis=dict(dtick=1))
 # Usar scroll de página cuando se muestran todos los equipos; nunca ocultar camiones.
 fig.update_layout(template='plotly_white',font=dict(size=12),margin=dict(l=10,r=10,t=15,b=10))
 st.plotly_chart(fig,width='stretch',config={'displaylogo':False})
st.caption('Gris claro: disponible sin viaje registrado · Verde: viaje registrado · Rojo: taller · Gris oscuro: sin registro.')
rows=[{'Camión':camion,**calc.resumen_dias(g,norm)} for camion,g in a.groupby('camion')]
st.subheader('Días por camión')
t=pd.DataFrame(rows)
if not t.empty:ui.tabla(t[['Camión','base','disponibles','viaje','taller','sin_viaje','sin_registro']].rename(columns={'base':'Días base','disponibles':'Disponibles','viaje':'Asociados a viajes','taller':'Taller','sin_viaje':'Disponibles sin viaje','sin_registro':'Sin registro'}),'disponibilidad')

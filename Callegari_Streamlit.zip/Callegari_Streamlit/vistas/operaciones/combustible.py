import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from core import ui,indicadores as calc
meta,periodo,fechas=ui.contexto();i,f,ip,fp=fechas
ui.cabecera('Combustible y rendimiento','Cantidades reales sin ponderar; la ponderación se aplica únicamente al rendimiento.')
ui.periodo_caption(fechas);ui.aviso_poblacion()
d=ui.filtro_camiones(ui.cargar('combustible_mes'),'comb_camiones')
a=d[d.mes.eq(i)];r=d[d.mes.eq(ip)];v=calc.combustible(a);ref=calc.combustible(r)
parcial=f<(i+pd.offsets.MonthEnd(0))
cols=st.columns(4)
for col,key,label,dec,unit in zip(cols,['rendimiento','rendimiento_gps','litros','km'],['Ponderado odómetro','Ponderado GPS','Litros del período','Km de odómetro'],[2,2,2,2],[' km/l',' km/l',' l',' km']):
 with col:ui.metrica(label,v[key],None if parcial else ref[key],dec=dec,unidad=unit)
if parcial:st.info('Mes parcial al corte: no se compara el combustible de una ventana mensual incompleta con un mes anterior completo.')
st.caption(f"Rendimientos válidos de odómetro: {v['validos']} de {v['con_litros']} camiones con litros. Rango inclusivo: 1–4 km/l.")
h=d[d.mes.dt.year.eq(i.year)].copy();h=h[h.mes+pd.offsets.MonthEnd(0)<=meta.fecha_corte]
rows=[{'Mes':m,**calc.combustible(g)} for m,g in h.groupby('mes')];trend=pd.DataFrame(rows)
if not trend.empty:
 fig=go.Figure()
 for key,label,color in [('rendimiento','Odómetro',ui.ROJO),('rendimiento_gps','GPS',ui.VERDE)]:fig.add_scatter(x=trend.Mes,y=trend[key],mode='lines+markers',name=label,line_color=color)
 st.subheader('Rendimiento mensual');fig.update_traces(hovertemplate='%{x|%m/%Y}<br>%{y:.2f} km/l<extra>%{fullData.name}</extra>');fig.update_yaxes(tickformat='.2f');ui.grafico(fig)
st.subheader('Detalle por camión')
a=a.copy();a['calidad']=a['calidad'].replace({'Extremos disponibles':'Con lecturas','Odometro retrocede; km no calculables':'Odómetro retrocede','Una sola fecha ATP':'Un dato ATP'})
st.caption('Con lecturas: hay lecturas inicial y final; no garantiza que el rendimiento esté dentro del rango. ATP identifica las lecturas de origen.')
ui.tabla(a[['camion','marca','modelo','litros','km','km_gps','rendimiento','rendimiento_gps','calidad']].rename(columns={'camion':'Camión','marca':'Marca','modelo':'Modelo','litros':'Litros','km':'Km odómetro','km_gps':'Km GPS','rendimiento':'Rendimiento odómetro','rendimiento_gps':'Rendimiento GPS','calidad':'Calidad'}),'combustible')
st.warning('Enero conserva la extracción histórica validada para km y litros. Los ponderados del impreso siguen pendientes de conciliación. Fuera de enero existen anomalías de odómetro en origen.')
st.caption('No se atribuye rendimiento a conductores sin una relación fiable entre personas y cargas. GPS aquí es kilometraje histórico del DW; no hay conexión a seguimiento GPS.')
